package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView img1;
    EditText edit1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img1 = (ImageView) findViewById(R.id.img1);
        edit1 = (EditText) findViewById(R.id.edit1);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater mInflater = getMenuInflater();
        mInflater.inflate(R.menu.menu1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.item0:
                if(!edit1.getText().toString().isEmpty()) {
                    img1.setRotation(Float.parseFloat(edit1.getText().toString()));
                }else {
                    edit1.setText("0");
                    img1.setRotation(0);
                }
                return true;
            case R.id.item1:
                img1.setImageResource(R.drawable.cat);
                item.setChecked(true);
                return true;
            case R.id.item2:
                img1.setImageResource(R.drawable.tomato);
                item.setChecked(true);
                return true;
            case R.id.item3:
                img1.setImageResource(R.drawable.dog);
                item.setChecked(true);
                return true;
        }
        return false;
    }
}