package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ProgressBar pb1, pb2;
        Button btn;
        TextView tv1, tv2;

        pb1 = (ProgressBar) findViewById(R.id.pb1);
        pb2 = (ProgressBar) findViewById(R.id.pb2);
        btn = (Button) findViewById(R.id.button1);

        tv1 = (TextView) findViewById(R.id.tv1);
        tv2 = (TextView) findViewById(R.id.tv2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() { // 하나의 스레드
                    public void run() {
                        for(int i = pb1.getProgress(); i < 100; i = i + 2) {
                            runOnUiThread(new Runnable() { // runOnUiThread : progressBar를 다른 위젯(textView)에 동시 출력할 경우 사용, 함수가 두개이기 때문
                                @Override
                                public void run() { // 하나의 스레드에 동시에 발생할 함수를 두개 사용하기 위해 runOnUiThread를 사용
                                    pb1.setProgress(pb1.getProgress() + 2);
                                    tv1.setText("1번 진행률 : " + pb1.getProgress() + "%");
                                }
                            });
                            SystemClock.sleep(100);
                        }
                    }
                }.start();

                new Thread() { // 하나의 스레드
                    public void run() {
                        for(int i = pb2.getProgress(); i < 100; i++) {
                            runOnUiThread(new Runnable() { // runOnUiThread : progressBar를 다른 위젯(textView)에 동시 출력할 경우 사용, 함수가 두개이기 때문
                                @Override
                                public void run() { // 하나의 스레드에 동시에 발생할 함수를 두개 사용하기 위해 runOnUiThread를 사용
                                    pb2.setProgress(pb2.getProgress() + 2);
                                    tv2.setText("2번 진행률 : " + pb2.getProgress() + "%");
                                }
                            });
                            SystemClock.sleep(100);
                        }
                    }
                }.start();

            }

        });

    }
}