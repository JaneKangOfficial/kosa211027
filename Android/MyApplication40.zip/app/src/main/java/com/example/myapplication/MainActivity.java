package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listViewMP3;
    Button btnPlay, btnStop;
    TextView tvMP3;
    TextView tvTime;
    ProgressBar pbMP3;

    ArrayList<String> mp3List;
    String selectedMP3;
    String mp3Path = "/sdcard/";
    MediaPlayer mPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, MODE_PRIVATE);

        setTitle("간단 MP3 플레이어");

        // .listFiles() : 파일 여러개 불러올 때 배열 사용
        File[] listFiles = new File(mp3Path).listFiles(); // sdcard에 있는 모든 파일
        mp3List = new ArrayList<String>();

        // 확장자가 .mp3인것만 가져오기 위해 변수 선언
        // fileName : 확장자 포함한 파일명, extName : 확장자
        String fileName, extName;
        for(File file : listFiles) {
            fileName = file.getName();
            // mp3 글자를 가져오기 위해 substring 사용
            // extName = fileName.substring(fileName.lastIndexOf("."));
            extName = fileName.substring(fileName.length() - 3);
            if(extName.equals((String)"mp3")) {
                mp3List.add(fileName); // 확장자가 mp3인 파일만 mp3List에 저장
            }
        }

        listViewMP3 = (ListView) findViewById(R.id.listViewMP3);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_single_choice,
                mp3List
        );
        listViewMP3.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        listViewMP3.setAdapter(adapter);
        listViewMP3.setItemChecked(0, true);

        listViewMP3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                selectedMP3 = mp3List.get(i);
            }
        });
        selectedMP3 = mp3List.get(0);
        btnPlay = (Button) findViewById(R.id.btnPlay);
        btnStop = (Button) findViewById(R.id.btnStop);
        tvMP3 = (TextView) findViewById(R.id.tvMP3);
        pbMP3 = (ProgressBar) findViewById(R.id.pbMP3);
        tvTime = (TextView) findViewById(R.id.tvTime);

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    mPlayer = new MediaPlayer();
                    mPlayer.setDataSource(mp3Path + selectedMP3);
                    mPlayer.prepare();
                    mPlayer.start(); // 음악시작
                    btnPlay.setClickable(false); // 비활성화
                    btnStop.setClickable(true); // 활성화
                    tvMP3.setText("실행 중인 음악 : " + selectedMP3);
                    new Thread() {
                        SimpleDateFormat timeFormat = new SimpleDateFormat("mm:ss");
                        public void run() {
                            if (mPlayer == null) return;
                            pbMP3.setMax(mPlayer.getDuration()); // progressBar를 실행 크기만큼 줌
                            while (mPlayer.isPlaying()) { // mp3 만큼 반복
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        pbMP3.setProgress(
                                                mPlayer.getCurrentPosition() // 현재 실행 위치
                                        );
                                        tvTime.setText("진행 시간 : " + timeFormat.format(mPlayer.getCurrentPosition()));
                                    }
                                });
                                SystemClock.sleep(200); // 쉬는시간(유휴시간) 0.2초
                            }

                        }
                    }.start();

                }catch(IOException e) {
                    e.printStackTrace();
                }
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPlayer.stop();
                mPlayer.reset();
                btnPlay.setClickable(true);
                btnStop.setClickable(false);
                tvMP3.setText("실행 중인 음악 : ");
                pbMP3.setProgress(0);
                tvTime.setText("진행 시간 : ");
            }
        });
        btnStop.setClickable(false);

    }
}