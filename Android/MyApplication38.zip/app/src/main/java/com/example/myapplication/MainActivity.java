package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {
//    함수와 스레드 차이
//    스레드

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ProgressBar pb1, pb2;
        final Button btn;
        pb1 = (ProgressBar) findViewById(R.id.pb1);
        pb2 = (ProgressBar) findViewById(R.id.pb2);
        btn = (Button) findViewById(R.id.button1);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*
                // 10초 후 마지막 결과로 이동
                for(int i = 0; i < 100; i++) {
                    pb1.setProgress(pb1.getProgress() + 2);
                    pb2.setProgress(pb1.getProgress() + 1);
                    SystemClock.sleep(100); // 0.1초마다 실행행
                }
                */

                /* 스레드
                10초 동안 이동하는것이 보임
                pb1, pb2 동시실행처럼 보이지만 pb1이 쉬어야 pb2가 실행, pb2가 쉬어야 pb1이 실행
                스레드가 알아서 작업시간과 간격을 스케줄링
                 */
                new Thread() {
                    public void run() {
                     for(int i = pb1.getProgress(); i < 100; i++) {
                         pb1.setProgress(pb1.getProgress() + 2);
                         SystemClock.sleep(100);
                     }
                    }
                }.start();

                new Thread() {
                    public void run() {
                        for(int i = pb2.getProgress(); i < 100; i++) {
                            pb2.setProgress(pb2.getProgress() + 1);
                            SystemClock.sleep(100);
                        }
                    }
                }.start();

            }
        });

    }
}