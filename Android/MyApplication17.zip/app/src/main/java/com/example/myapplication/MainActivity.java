package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edit1, edit2;
    Button btnAdd, btnSub, btnMul, btnDiv;
    TextView textResult;
    String num1, num2;
    Integer result;
    Button[] numButtons = new Button[10];
    Integer[] numBtnIDs = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};
    Button numButtons0;
    Button btn[] = new Button[4];
    Integer[] btnIDs = {R.id.sum, R.id.sub, R.id.mul, R.id.div};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("테이블 레이아웃 계산기");
        Integer edt1 = R.id.num1;
        edit1 = (EditText) findViewById(edt1);
        edit2 = (EditText) findViewById(R.id.num2);
        btnAdd = (Button) findViewById(R.id.sum);
        btnSub = (Button) findViewById(R.id.sub);
        btnMul = (Button) findViewById(R.id.mul);
        btnDiv = (Button) findViewById(R.id.div);
        textResult = (TextView) findViewById(R.id.result);
        numButtons0 = (Button) findViewById(R.id.btn0);

        for(int i = 0; i < numButtons.length; i++) {
            numButtons[i] = (Button) findViewById(numBtnIDs[i]);
        }
        // 0 : numButtons[0], 1 : numButtons[1], 2 : numButtons[2], ..., 9 : numButtons[9]

//        numButtons0.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if(edit1.isFocused()) {
//                    num1 = edit1.getText().toString() + numButtons0.getText().toString();
//                    edit1.setText(num1);
//                }else if(edit2.isFocused()) {
//                    num2 = edit2.getText().toString() + numButtons0.getText().toString();
//                    edit2.setText(num2);
//                }
//            }
//        });

        for(int i = 0; i < numButtons.length; i++) {
            final int idx; // 안드로이드에서 index를 사용하기 위해서는 final 이라고 꼭 먼저 선언해줘야 한다.
            idx = i;
            numButtons[idx].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(edit1.isFocused()) {
                        num1 = edit1.getText().toString() + numButtons[idx].getText().toString();
                        edit1.setText(num1);
                    }else if(edit2.isFocused()) {
                        num2 = edit2.getText().toString() + numButtons[idx].getText().toString();
                        edit2.setText(num2);
                    }else {
                        Toast.makeText(getApplicationContext(), "텍스트를 선택하세요.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

//        btnAdd.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View view, MotionEvent motionEvent) {
//                num1 = edit1.getText().toString();
//                num2 = edit2.getText().toString();
//                result = Integer.parseInt(num1) + Integer.parseInt(num2);
//                textResult.setText("계산 결과 : " + result.toString());
//                return false;
//            }
//        });
//
//        btnSub.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View view, MotionEvent motionEvent) {
//                num1 = edit1.getText().toString();
//                num2 = edit2.getText().toString();
//                result = Integer.parseInt(num1) - Integer.parseInt(num2);
//                textResult.setText("계산 결과 : " + result.toString());
//                return false;
//            }
//        });
//
//        btnDiv.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View view, MotionEvent motionEvent) {
//                num1 = edit1.getText().toString();
//                num2 = edit2.getText().toString();
//                result = Integer.parseInt(num1) / Integer.parseInt(num2);
//                textResult.setText("계산 결과 : " + result.toString());
//                return false;
//            }
//        });
//
//        btnMul.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View view, MotionEvent motionEvent) {
//                num1 = edit1.getText().toString();
//                num2 = edit2.getText().toString();
//                result = Integer.parseInt(num1) * Integer.parseInt(num2);
//                textResult.setText("계산 결과 : " + result.toString());
//                return false;
//            }
//        });

        for(int i = 0; i < btn.length; i++) {
            btn[i] = (Button) findViewById(btnIDs[i]);
        }

        for(int i = 0; i < btn.length; i++) {
            final int idx;
            idx = i;

            btn[idx].setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    num1 = edit1.getText().toString();
                    num2 = edit2.getText().toString();
                    switch (btn[idx].getText().toString()) {
                        case "더하기" :
                            result = Integer.parseInt(num1) + Integer.parseInt(num2);
                            break;
                        case "빼기" :
                            result = Integer.parseInt(num1) - Integer.parseInt(num2);
                            break;
                        case "곱하기" :
                            result = Integer.parseInt(num1) * Integer.parseInt(num2);
                            break;
                        case "나누기" :
                            result = Integer.parseInt(num1) / Integer.parseInt(num2);
                            break;
                    }
                    textResult.setText("계산 결과 : " + result.toString());
                    return false;
                }
            });
        }

    }
}