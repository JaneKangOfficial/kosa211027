package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.ToggleButton;

// iphone 용은 swift 언어로 개발 (6개월마다 버전 변경)
// mac 용은 objective c 언어로 개발
// windows 용은 C# 언어로 개발

public class MainActivity extends AppCompatActivity {
    // 1. 변수명 사용
    CheckBox myCheck;
    Switch mySwitch;
    ToggleButton myToggleButton;
    RadioButton myRadioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 2. 위젯 불러오기
        myCheck = (CheckBox)findViewById(R.id.android);
        mySwitch = (Switch)findViewById(R.id.switch1);
        myToggleButton = (ToggleButton)findViewById(R.id.toggleButton1);
        myRadioButton = (RadioButton)findViewById(R.id.radio0);

        // 3. OnCheckedChangeListener 사용 - html js onChecked onClick event 와 같음
        myCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                // 4. 코드 작성
            }
        });

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                // 코드 작성
            }
        });

        myToggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                // 코드 작성
            }
        });

        myRadioButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                // 코드 작성
            }
        });

    }
}