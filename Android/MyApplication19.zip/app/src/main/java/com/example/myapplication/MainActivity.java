package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edit1, edit2;
    TextView textResult;
    String num1, num2;
    Integer result;
    Button[] numButtons = new Button[10];
    Integer[] numBtnIDs = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};
    Button btn[] = new Button[4];
    Integer[] btnIDs = {R.id.sum, R.id.sub, R.id.mul, R.id.div};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("그리드테이블 계산기");
        edit1 = (EditText) findViewById(R.id.num1);
        edit2 = (EditText) findViewById(R.id.num2);
        textResult = (TextView) findViewById(R.id.result);

        for(int i = 0; i < numButtons.length; i++) {
            numButtons[i] = (Button) findViewById(numBtnIDs[i]);
        }

        for(int i = 0; i < numButtons.length; i++) {
            final int idx;
            idx = i;
            numButtons[idx].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(edit1.isFocused()) {
                        num1 = edit1.getText().toString() + numButtons[idx].getText().toString();
                        edit1.setText(num1);
                    }else if(edit2.isFocused()) {
                        num2 = edit2.getText().toString() + numButtons[idx].getText().toString();
                        edit2.setText(num2);
                    }else {
                        Toast.makeText(getApplicationContext(), "텍스트를 선택하세요.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        for(int i = 0; i < btn.length; i++) {
            btn[i] = (Button) findViewById(btnIDs[i]);
        }

        for(int i = 0; i < btn.length; i++) {
            final int idx;
            idx = i;
            btn[idx].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    num1 = edit1.getText().toString();
                    num2 = edit2.getText().toString();
                    switch (btn[idx].getText().toString()) {
                        case "더하기" :
                            result = Integer.parseInt(num1) + Integer.parseInt(num2);
                            break;
                        case "빼기" :
                            result = Integer.parseInt(num1) - Integer.parseInt(num2);
                            break;
                        case "곱하기" :
                            result = Integer.parseInt(num1) * Integer.parseInt(num2);
                            break;
                        case "나누기" :
                            result = Integer.parseInt(num1) / Integer.parseInt(num2);
                            break;
                    }
                    textResult.setText("계산 결과 : " + result);
                }
            });
        }

    }
}